//this code is heavily influenced by this source: https://www.youtube.com/watch?v=R1S_NhKkvGA

const textElement = document.getElementById('text')
const optionButtonsElement = document.getElementById('option-buttons')

let inventory = {}

function startGame() {
  inventory = {}
  showTextNode(1)
}

function showTextNode(nodeIndex) {
  var img = document.getElementsByTagName('body')[0]
  const textNode = textNodes.find(textNode => textNode.id == nodeIndex)
  img.className = textNode.where 
  textElement.innerText = textNode.text
  while (optionButtonsElement.firstChild) {
  optionButtonsElement.removeChild(optionButtonsElement.firstChild)
  }

  textNode.options.forEach(option => {
    if (showOption(option)) {
      const button = document.createElement('button')
      button.innerText = option.text
      button.classList.add('btn')
      button.addEventListener('click', () => selectOption(option))
      optionButtonsElement.appendChild(button)
    }

  })
}

function showOption(option) {
  return option.requiredState == null || option.requiredState(inventory)
}

function selectOption(option) {
  const nextTextNodeId = option.nextText
  if (nextTextNodeId <= 0) {
    return startGame()
  }
  inventory = Object.assign(inventory, option.setState)
  showTextNode(nextTextNodeId)
}


const textNodes = [
  {
    id: 1,
      text: "You are in a convienceStore, there's some interesting items like a kawaii knife.",
      where: 'convienceStore',
      options: [
        {
          text: 'Purchase the kawaii knife',
          requiredState: (currentState) => !currentState.kawaiiKnife,
          setState: { kawaiiKnife: true },
          nextText: 1
        },
        {
          text: 'Purchase Ramen',
          requiredState: (currentState) => !currentState.Ramen,
          setState: { Ramen: true },
          nextText: 1
        },
        {
          text: 'Purchase Coke and leave',
          requiredState: (currentState) => !currentState.Coke,
          setState: { Coke: true },
          nextText: 1
        },
        {
          text: "I'm gonna leave now",
          nextText: 2 
        }
      ]
  },
  //{
  //   id: 2,
  //     text: 'You venture forth in search of answers to where you are when you come across a merchant.',
  //     where: 'outside',
  //       options: [
  //         {
  //           text: 'Trade the goo for a sword',
  //           requiredState: (currentState) => currentState.blueGoo,
  //           setState: { blueGoo: false, sword: true },
  //           nextText: 3
  //         },
  //         {
  //           text: 'Trade the goo for a shield',
  //           requiredState: (currentState) => currentState.blueGoo,
  //           setState: { blueGoo: false, shield: true },
  //           nextText: 3
  //         },
  //         {
  //           text: 'Ignore the merchant',
  //           nextText: 3
  //         }
  //       ]
  // },
  {
    id: 2,
      text: "You are now outside, waiting by the cross road for the cross walk sine to turn on. Right then you realize there is a shortcut to your place that you'de never tried out before, but turning back to the store and grabbing some extra stuff is also a good option",
      where: 'outside',
        options: [
          {
            text: 'take the shortcut',
            nextText: 24
          },
          {
            text: 'keep waiting for the sine',
            nextText: 3
          },
          {
            text: 'turn back to the store',
            nextText: 1
          }
        ]
  },
  {
    id: 3,
      text: "after a few minute, the sine still hasn't turned on despite the fact no cars has passed by in the pass few minute. Just as you get impatient, an old man showed up begging for food",
      where: 'outside',
        options: [
          {
            text: 'gave him the ramen and ask for something in return',
            requiredState: (currentState) => currentState.Ramen,
            setState: { Ramen: false, AK47: true },
            nextText: 4
          },
          {
            text: 'gave him the ramen',
            requiredState: (currentState) => currentState.Ramen,
            setState: { Ramen: false, AK47: true },
            setState: { crackCocaine: true },
            nextText: 5
          },
          {
            text: 'Ignore the old man',
            nextText: 7
          },
          {
            text: 'Ignore the old man and run cross the street',
            nextText: 8
          }
        ]
  },
  // {
  //   id: 3,
  //     text: 'After leaving the merchant you start to feel tired and stumble upon a small town next to a dangerous looking castle.',
  //       options: [
  //         {
  //           text: 'Explore the castle',
  //           nextText: 4
  //         },
  //         {
  //           text: 'Find a room to sleep at in the town',
  //           nextText: 5
  //         },
  //         {
  //           text: 'Find some hay in a stable to sleep in',
  //           nextText: 6
  //         }
  //       ]
  // },
  {
    id: 4,
      text: "he says that he can't afford food but he can afford ammo (I have no idea how based on the current state of the market) and decides to give you his AK47 which he somehow had conceal carried on the street",
        where: "outside",
        options: [
          {
            text: 'Take the AK47 graciously',
            setState: {AK47: true},
            nextText: 6
          },
          {
            text:"Take the AK from him and shoot him in the head. No witnesses",
            setState: {AK47: true},
            nextText: 6
          },
          {
            text: 'You decide not to take the AK47, you feel that you will be okay without it. Turns out he was insulted by this and shot you in the head',
            nextText: -1
          }
        ]
  },
  {
    id: 5,
      text: 'The man looks kindly on you and gives you an AK47 and Crack Cocaine! This is starting to sound like the best night ever!',
      where: "outside",
        options: [
          {
            text: 'You take both the crack cocaine and the AK, all of a sudden you see the cross walk light turn to walk and you continue',
            nextText: 12
          }
        ]
  },
  {
      id: 6,
      text: 'You shoot him in the head but make sure to leave no witnesses so you have to shoot the rat and a couple pedestrians looking at you as well',
      where: "outside",
        options: [
          {
            text: 'There were gunshots heard in your area, prepare for trouble',
            requiredState: (currentState) => currentState.AK47,
            nextText: 9
          }
      
      ]
  },
  {
    id: 7,
      text: 'The old man pull out an AK47 out of no where and shot you',
        options: [
          {
            text: 'Restart',
            nextText: -1
          }
        ]
  },
  {
    id: 8,
      text: 'You started running but all in a sudden a truck showed up out of no where and runned you over',
        where: "truck",
        options: [
          {
           text: 'What did Jesus say about giving to the poor? God himself was displeased and smited you with 12 tons of metal and rubber',
           nextText: 22
        }
        ]
  },
  {
    id: 9,
    where: "gearUp",
      text: 'You start to hear sirens in the distance, you pull out your level 6 armor and put on your Altyn that you conviently had on you at the time. You find an abandoned building and barricade it. As the sirens are getting closer you start to get a little bit anxious and all of a sudden you hear the cops yelling at you, telling you to come out unarmed',
        options: [
          {
            text: "You didnt gear up for nothing if its a fight they want its a fight they've got!",
            nextText: 10
          },
          {
            text: 'You crack under the pressure and come out, however a cop thought you were still armed and shot you in the head! Fortunately for you, you had your Altyn on so the bullet bounced off and hit a differnt cop. Unfortunately for you, they started opening fire because they thought you just shot a cop.',
            nextText: 21
          }
          
        ]
  },
  {
    id: 10,
      text: 'You decide to open fire on the cops, they shoot at you but their bullets bounce off you harmlessly beause of your high level armor! All of a sudden you feel a sharp pain in your right arm, you were shot! There are a lot of them so you duck under a counter for cover. You hear bullets fly and you start to wonder if you made the right choice, you start to regret not asking out the person you had a crush on, not saying hello to your parents in the morning, for being an asshole because you thought it would make people like you. However, your a sigma male, the grindset never stops. You remember who and what your fighting for, you repeak despite being surrounded and have being shot in the arm. Then you get shot in the leg and go down, they rush into your complex and capture you',
        where: "abandoned",
        options: [
          {
            text: 'They took your AK from you but they didnt realize you still had a knife! You unsheath your kawaii knife and all of a sudden the truck your in gets sliced in half! You jump out but wonder what to do next',
            requiredState: (currentState) => currentState.kawaiiKnife,
            setState: { kawaiiKnife: false },
            nextText: 11
          },
          {
            text: 'You wish you had a weapon on you. They bring you to prison and you get sentenced to death',
            nextText: 22
          }
        ]
  },
  {
    id: 11,
      text: 'You recognize where you are and your presented with differnt options ',
        where: "choice",
        options: [
          {
            text: 'Do you go home?',
            nextText: 12
          },
          {
            text: 'Do you go back to the convinece store to keep shopping?',
            nextText: -1
          },
          {
            text: 'You see a bar, do you go into it and grab a drink?',
            nextText: 13
          }
        ]
  },
  {
    id: 12, 
      text: "You are on your way home when all of a sudden a mercedes G wagon goes by and then stops ahead. You start to get a bad feeling. The mercedes G wagon does a u-turn and starts driving towards you. You see the window start going down and see a man peak out of it wielding a Vector. What do you do?",
      where: "SUV",
      options: [
        {
          text: "Do you A) dive into a ditch nearby?",
          nextText: 14
        },
        {
          text: "Do you B) start running away from the oncomming SUV?",
          nextText: 15
        },
        {
          text: "pull out the kawaii knife and hope it saves you",
          requiredState: (currentState) => currentState.kawaiiKnife,
          setState: { kawaiiKnife: false },
          nextText: 14
        },
        {
          text: "Or do you D) set up your DSHK heavy machine gun and gun down the mercedes G wagon",
          nextText: 16
        }
      ]
  },
  {
    id: 13, 
      text: "You go inside the bar in hopes of something to make your night a little better. A lot of people are looking at you sincce your wearing an Altyn and level 6 body armor, but you dont care. You have a couple shots of vodka and leave without paying the bill because your that sigma",
      where: "bar", 
      options: [
        {
          text: "You see an abandoned Mazda RX-7 that has its doors unlocked and the keys are in the key hole. Looks like tonight might still turn out to be a good night. You drive off into the sunrise in your dream car, not having a care in the world. No unfortunately that is not the case, you decided to drink and drive, and crashed into a tree and died, or did you?",
          nextText: 20
        }
      ]
      
  },
  {
    id: 14, 
    where: "home",
      text: "You dive into the ditch just as a couple bullets hit some trees behind you, the car keeps on going perhaps they thought you died? You could have sworn you recognized the man though. You continue walking back home and finally make it to your appartment complex and fall asleep",
      options: [
        {
          text: "You wake up and realize that your kind of hungry, do you go to the convience store?",
          nextText: -1
        },
        {
          text: "Or do you decide to play final fantasy 14 for an ungodly amount of time",
          nextText: 18
        },
        {
          text: "Or perhaps you go to sleep since your still feeling tired",
          nextText: 17
        }
      ]
  },
  {
    id: 15, 
    where: "emptyRoadnight",
      text: "You died but what did you expect by running down an empty open road at night?",
      options: [
        {
          text: "Continue",
          nextText: 19
        }
      ]
  },
  {
    id: 16, 
      where: "gun",
      text: "You gun down the Mercedes G Wagon with your DSHK and you see it swerve off the road and into the river below, you pack up and start going home",
     options: [
        {
          text: "Continue",
          nextText: 14
        }
      ]
  },
  {
    id: 17, 
    where: "halfBlackhalfWhiteRoom",
      text: "You hear a voice, first its silent but then it gets louder and louder. Its telling you to wake up! Wake up! WAKE UP! You recognize the voice, but couldnt tell who it belonged to. You see half the room your in surrounded by darkness and the other half surrounded by light",
      options: [
        {
          text: "You walk towards the light, you feel its warmth and it comforts you and feels nice, you fully walk into the light",
          nextText: 21
        },
        {
          text: "You walk towards the darkness, it closes in around you and everything goes numb, you feel safe but also feel disconnected from reality",
          nextText: 22
        }
      ]
  },
  {
    id: 18, 
    where: "lowResExplosion",
      text: "All of a sudden you hear a window break and an explosion goes off. Someone threw a grenade into your apartment",
      nextText: 19
  },
  {
    id: 19, 
    where: "gameOver",
      text: "You died, but didn't get reincarnated. Unlucky. You can play again or save yourself the brain cells and do something more productive then looking at our shit show of a projcet",
  },
  {
    id: 20, 
      text: "You survived",
      options: [
        {
          text: "You walk home",
          nextText: 14
        }
      ]
  },
  {
    id: 21,
      text: "the light around you started fading away, you are able to feel again, the heat of the sunlight, the slite friction bewteen your skin and the air, wind breezing through you hair, you started hairing chit chats, you started to see things,actually peoples, standing all aruond you, speaking a language that you've never heard but somehow comprehend. Stareing at you with eyes blends with fear and surprise",
        where: "people",
        options: [
          {
            text: 'hello?... um... where is this?',
            nextText: 24,
          },
          {
            text: "stand up and run",
            nextText: 25,
          },
          {
            text: "pretend to be some kind fo demon just to scare them",
            nextText: 26,
          },
          {
            text: "sit there and starts crying like a newborn",
            nextText: 27,
          }
        ]
  },
  {
    id: 22,
      text: "the darkness you were emerged in backed down. The air, you breath it in, doesn't felt a thing at all, not even the flow of air through your nossel. You stood up, looked around realizeing you are in the middfl of a forest but strangely you don't hear a thing, not even the charping of birds. You see a village ahead of you.",
        where:"forest",
        options: [
          {
            text: "go check out the village",
            nextText: 28
          },
          {
            text: "",
            nextText: 29
          },
          {
            text: "",
            nextText: 30
          }
        ]
  },
  {
    id: 23,
      text: "two different path showed up infront of you, one glorious elumenated with golden light, the other dark and empty but somehow seems more welcoming to you",
        where:"choice",
        options: [
          {
            text: "walk into the light",
            nextText: 21
          },
          {
            text: "walk into the darkness",
            nextText: 22
          }
        ]
  },
  {
    id: 24,
      text: "as you said it",
      where: "people",
  },
  {
    id: 25, 
      text: "",
  },
    {
    id: 26, 
      text: ""
  },
    {
    id: 27, 
      text: ""
  },
    {
    id: 28, 
      text: ""
  },
    {
    id: 29, 
      text: ""
  },
    {
    id: 30, 
      text: ""
  },
]

    startGame()